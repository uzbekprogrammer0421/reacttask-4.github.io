import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { nanoid } from 'nanoid'
import './App.css'

function App() {
  const [users, setUsers] = useState([])
  const [form, setForm] = useState({})
  const [search, setSearch] = useState("")
  const handleSubmit = (event) => {
    event.preventDefault()
    let id = nanoid()
    const payload = {...form, id}
    const formData = new FormData(event.target);
    const newUser = {
      name: formData.get("name"),
      age: formData.get("age"),
      phone: formData.get("phone"),
      address: formData.get("address")
    };
    setUsers([...users, newUser]);
  }
  const deleteUser =(i)=>{
    let new_arr = users.filter((item,index) => index !== i )
    setUsers([...new_arr])
  }
  console.log(search);
  return (
    <>
      <div className="container">
        <div className="row mt-4 ">
          <div className="col-md-4">
            <div className="card">
              <div className="card-body">
                <form id="submit" onSubmit={handleSubmit}>
                  <input type="text" name="name" placeholder="Name" className="form-control my-2" />
                  <input type="text" name="age" placeholder="Age" className="form-control my-2" />
                  <input type="text" name="phone" placeholder="Phone" className="form-control my-2" />
                  <input type="text" name="address" placeholder="Address" className="form-control my-2" />
                  <button type="submit" className="btn btn-primary mt-2">Add user</button>
                </form>
              </div>
            </div>
          </div>
          <div className="col-md-8">
            <div className="row">
              <div className="col-md-6">
                <input type="text" placeholder="Search..." onChange={(e)=> setSearch(e.target.value)} className="form-control mb-2" />
              </div>
            </div>
            <table className="table table-bordered table-hover table-striped">
              <thead>
                <tr>
                  <td>T/R</td>
                  <td>Name</td>
                  <td>Age</td>
                  <td>Phone</td>
                  <td>Address</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                {
                  users.filter((item)=>{
                    if (item.name.includes(search)) {
                      return item
                    }
                  }).map((item, index) => {
                    return (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{item.name}</td>
                        <td>{item.age}</td>
                        <td>{item.phone}</td>
                        <td>{item.address}</td>
                        <td>
                          <button className="btn btn-danger" onClick={()=>deleteUser(index)} ><i className="fa-solid fa-trash-can"></i></button>
                        </td>
                      </tr>
                    )
                  })
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

export default App